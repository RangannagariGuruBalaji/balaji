import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppRoot } from './app/app-root.component';

const STORAGE_KEY = 'patient-dashboard-data';

function ensureDataSdk() {
  if (window.dataSdk) return;

  let handler: { onDataChanged: (data: any[]) => void } | null = null;

  const load = (): any[] => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  };

  const save = (data: any[]) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    handler?.onDataChanged(data);
  };

  window.dataSdk = {
    async init(h) {
      handler = h;
      const data = load();
      handler?.onDataChanged(data);
      return { isOk: true };
    },
    async create(patient) {
      const data = load();
      const withId = { __backendId: crypto.randomUUID(), ...patient };
      data.push(withId);
      save(data);
      return { isOk: true, data: withId };
    },
    async update(patient) {
      const data = load();
      const idx = data.findIndex(p => p.__backendId === patient.__backendId);
      if (idx === -1) return { isOk: false };
      data[idx] = { ...data[idx], ...patient };
      save(data);
      return { isOk: true, data: data[idx] };
    },
    async delete(patient) {
      const data = load();
      const filtered = data.filter(p => p.__backendId !== patient.__backendId);
      save(filtered);
      return { isOk: true };
    }
  };
}

ensureDataSdk();

bootstrapApplication(AppRoot, appConfig)
  .catch((err) => console.error(err));
