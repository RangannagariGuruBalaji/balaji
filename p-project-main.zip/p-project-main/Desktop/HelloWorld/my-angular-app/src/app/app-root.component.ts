import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FilterPipe } from './filter.pipe';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule, FilterPipe, HttpClientModule],
  templateUrl: './app-root.component.html',
  styleUrls: ['./app-root.component.css']
})
export class AppRoot implements OnInit {
  private apiUrl = 'http://localhost:5000/api/patients';
  private appointmentsApiUrl = 'http://localhost:5000/api/appointments';
  title = 'my-angular-app';
  patients: any[] = [];
  appointments: any[] = [];
  editingPatient: any = null;
  editingAppointment: any = null;
  showAppointmentModal = false;
  appointmentSaveSuccess = false;
  showExportMenu = false;
  showAboutUs = false;
  isDarkMode = false;
  appointmentForm: any = {
    patient_name: '',
    date: '',
    time: '',
    doctor: '',
    department: '',
    notes: '',
    status: 'scheduled'
  };
  form: any = {
    name: '',
    age: '',
    gender: 'female',
    blood_group: '',
    diagnosis: '',
    status: 'admitted',
    doctor: '',
    room: '',
    admission_day: new Date().getDate(),
    admission_month: (new Date().getMonth() + 1).toString(),
    admission_year: new Date().getFullYear()
  };
  isLoading = false;
  showModal = false;
  showMenu = false;
  filterStatus = 'all';
  searchQuery = '';
  activeView: 'patients' | 'analytics' | 'analytics2' | 'settings' | 'appointments' | 'admitted' | 'discharged' | 'critical' = 'patients';
  isLoggedIn = false;
  showRegistration = false;
  currentUser: any = null;
  loginForm = {
    username: '',
    password: ''
  };
  registerForm = {
    username: '',
    password: '',
    confirmPassword: '',
    email: ''
  };
  loginError = '';
  registerError = '';

  config = {
    background_color: "#f8fafc",
    surface_color: "#ffffff",
    text_color: "#1e293b",
    primary_action: "#3b82f6",
    secondary_action: "#64748b",
    font_family: "Inter",
    font_size: 14,
    dashboard_title: "Patient Management Dashboard",
    subtitle: "Healthcare Administration System"
  };

  stats = {
    total: 0,
    admitted: 0,
    critical: 0,
    discharged: 0,
    stable: 0,
    observation: 0,
    icu: 0
  };

  analytics = {
    statusMix: [] as Array<{ label: string; value: number; color: string; percent: number }>,
    genderMix: [] as Array<{ label: string; value: number; percent: number }>,
    ageBuckets: [] as Array<{ label: string; value: number; percent: number }>,
    weeklyAdmissions: [] as Array<{ label: string; value: number; percent: number }>,
    weeklyCritical: [] as Array<{ label: string; value: number }>,
    weeklyDischarged: [] as Array<{ label: string; value: number }>,
    weeklySparkline: '',
    criticalLinePath: '',
    dischargeLinePath: '',
    weeklyMax: 1,
    criticalPercent: 0,
    dischargePercent: 0
  };

  readonly agePieColors = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6'];
  readonly genderPieColors = ['#f87171', '#60a5fa', '#fbbf24', '#a78bfa'];

  constructor(private http: HttpClient) {}

  get filteredPatients() {
    let filtered = this.patients;
    if (this.filterStatus !== 'all') {
      filtered = filtered.filter(p => p.status?.toLowerCase() === this.filterStatus);
    }
    if (this.searchQuery) {
      const query = this.searchQuery.toLowerCase();
      filtered = filtered.filter(p => 
        (p.name?.toLowerCase().includes(query) || '') ||
        (p.patient_id?.toLowerCase().includes(query) || '') ||
        (p.diagnosis?.toLowerCase().includes(query) || '') ||
        (p.doctor?.toLowerCase().includes(query) || '')
      );
    }
    return filtered;
  }

  ngOnInit() {
    // Load saved settings
    const savedConfig = localStorage.getItem('dashboardConfig');
    if (savedConfig) {
      this.config = JSON.parse(savedConfig);
    }
    
    // Load dark mode preference
    const savedDarkMode = localStorage.getItem('isDarkMode');
    if (savedDarkMode === 'true') {
      this.isDarkMode = true;
    }
    
    // Check if user is already logged in
    const loggedIn = localStorage.getItem('isLoggedIn');
    const savedUser = localStorage.getItem('currentUser');
    if (loggedIn === 'true' && savedUser) {
      this.isLoggedIn = true;
      this.currentUser = JSON.parse(savedUser);
      this.initializeApp();
    }
    if (document.body) {
      document.body.style.backgroundColor = this.config.background_color;
      document.body.style.color = this.config.text_color;
      document.body.style.fontFamily = `${this.config.font_family}, Inter, sans-serif`;
      document.body.style.fontSize = `${this.config.font_size}px`;
    }
  }

  login() {
    this.loginError = '';
    this.isLoading = true;

    // Simple authentication - you can replace this with actual API call
    setTimeout(() => {
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const user = users.find((u: any) => u.username === this.loginForm.username && u.password === this.loginForm.password);
      
      if (user) {
        this.isLoggedIn = true;
        this.currentUser = { username: user.username, email: user.email };
        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('currentUser', JSON.stringify(this.currentUser));
        this.initializeApp();
        this.showToast('Login successful', 'success');
      } else {
        this.loginError = 'Invalid username or password';
        this.showToast('Invalid credentials', 'error');
      }
      this.isLoading = false;
    }, 500);
  }

  register() {
    this.registerError = '';
    
    // Validation
    if (!this.registerForm.username || !this.registerForm.password || !this.registerForm.email) {
      this.registerError = 'All fields are required';
      return;
    }
    
    if (this.registerForm.password !== this.registerForm.confirmPassword) {
      this.registerError = 'Passwords do not match';
      return;
    }
    
    if (this.registerForm.password.length < 6) {
      this.registerError = 'Password must be at least 6 characters';
      return;
    }
    
    this.isLoading = true;

    // Simple registration - you can replace this with actual API call
    setTimeout(() => {
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      
      // Check if username already exists
      if (users.find((u: any) => u.username === this.registerForm.username)) {
        this.registerError = 'Username already exists';
        this.isLoading = false;
        return;
      }
      
      // Add new user
      users.push({
        username: this.registerForm.username,
        password: this.registerForm.password,
        email: this.registerForm.email
      });
      
      localStorage.setItem('users', JSON.stringify(users));
      this.showToast('Registration successful! Please login', 'success');
      this.toggleForm();
      this.registerForm = { username: '', password: '', confirmPassword: '', email: '' };
      this.isLoading = false;
    }, 500);
  }

  toggleForm() {
    this.showRegistration = !this.showRegistration;
    this.loginError = '';
    this.registerError = '';
  }

  logout() {
    this.isLoggedIn = false;
    this.currentUser = null;
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('currentUser');
    this.patients = [];
    this.loginForm = { username: '', password: '' };
    this.showToast('Logged out successfully', 'success');
  }

  async initializeApp() {
    this.loadPatients();
    this.loadAppointments();
  }

  loadPatients() {
    this.http.get<any[]>(this.apiUrl).subscribe({
      next: (data) => {
        this.patients = data;
        this.updateStats();
        this.computeAnalytics();
      },
      error: (err) => {
        console.error('Failed to load patients:', err);
        this.showToast('Failed to load patients', 'error');
      }
    });
  }

  loadAppointments() {
    this.http.get<any[]>(this.appointmentsApiUrl).subscribe({
      next: (data) => {
        this.appointments = data;
      },
      error: (err) => {
        console.error('Failed to load appointments:', err);
        this.showToast('Failed to load appointments', 'error');
      }
    });
  }

  updateStats() {
    this.stats = {
      total: this.patients.length,
      admitted: this.patients.filter(p => p.status?.toLowerCase() === 'admitted').length,
      critical: this.patients.filter(p => p.status?.toLowerCase() === 'critical').length,
      discharged: this.patients.filter(p => p.status?.toLowerCase() === 'discharged').length,
      stable: this.patients.filter(p => p.status?.toLowerCase() === 'stable').length,
      observation: this.patients.filter(p => p.status?.toLowerCase() === 'observation').length,
      icu: this.patients.filter(p => p.status?.toLowerCase() === 'icu').length,
    };
    this.computeAnalytics();
  }

  computeAnalytics() {
    const total = this.patients.length || 1;
    const countByStatus = (status: string) => this.patients.filter(p => p.status?.toLowerCase() === status).length;

    const statusColors: Record<string, string> = {
      admitted: '#3b82f6',
      critical: '#ef4444',
      observation: '#0ea5e9',
      icu: '#f59e0b'
    };

    const statuses = ['admitted', 'critical', 'observation', 'icu'];
    this.analytics.statusMix = statuses.map(label => {
      const value = countByStatus(label);
      return { label, value, color: statusColors[label] || '#64748b', percent: Math.round((value / total) * 100) };
    });

    const genders = ['female', 'male', 'other', 'children'];
    this.analytics.genderMix = genders.map(label => {
      const value = this.patients.filter(p => p.gender?.toLowerCase() === label).length;
      return { label, value, percent: Math.round((value / total) * 100) };
    });

    const ageBucketsDef = [
      { label: '0-17', min: 0, max: 17 },
      { label: '18-35', min: 18, max: 35 },
      { label: '36-55', min: 36, max: 55 },
      { label: '56+', min: 56, max: Infinity }
    ];
    this.analytics.ageBuckets = ageBucketsDef.map(bucket => {
      const value = this.patients.filter(p => {
        const ageNum = Number(p.age);
        return !Number.isNaN(ageNum) && ageNum >= bucket.min && ageNum <= bucket.max;
      }).length;
      return { label: bucket.label, value, percent: Math.round((value / total) * 100) };
    });

    const today = new Date();
    const weekCounts: number[] = [];
    const weekCriticalCounts: number[] = [];
    const weekDischargedCounts: number[] = [];
    const weekLabels: string[] = [];
    for (let i = 6; i >= 0; i--) {
      const day = new Date(today);
      day.setDate(today.getDate() - i);
      const dayKey = day.toISOString().slice(0, 10);
      const count = this.patients.filter(p => (p.admission_date || '').slice(0, 10) === dayKey).length;
      const criticalCount = this.patients.filter(p => 
        (p.admission_date || '').slice(0, 10) === dayKey && 
        p.status?.toLowerCase() === 'critical'
      ).length;
      const dischargedCount = this.patients.filter(p => 
        (p.admission_date || '').slice(0, 10) === dayKey && 
        p.status?.toLowerCase() === 'discharged'
      ).length;
      weekCounts.push(count);
      weekCriticalCounts.push(criticalCount);
      weekDischargedCounts.push(dischargedCount);
      weekLabels.push(day.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }));
    }
    const weeklyMax = Math.max(...weekCounts, 1);
    this.analytics.weeklyMax = weeklyMax;
    this.analytics.weeklyAdmissions = weekCounts.map((v, idx) => ({ label: weekLabels[idx], value: v, percent: Math.round((v / weeklyMax) * 100) }));
    this.analytics.weeklyCritical = weekCriticalCounts.map((v, idx) => ({ label: weekLabels[idx], value: v }));
    this.analytics.weeklyDischarged = weekDischargedCounts.map((v, idx) => ({ label: weekLabels[idx], value: v }));
    this.analytics.weeklySparkline = this.buildSparklinePath(weekCounts);
    this.analytics.criticalLinePath = this.buildSparklinePath(weekCriticalCounts);
    this.analytics.dischargeLinePath = this.buildSparklinePath(weekDischargedCounts);

    this.analytics.criticalPercent = Math.round((countByStatus('critical') / total) * 100);
    this.analytics.dischargePercent = Math.round((countByStatus('discharged') / total) * 100);
  }

  getAgePieStyle() {
    const totalPercent = this.analytics.ageBuckets.reduce((sum, b) => sum + b.percent, 0);
    if (!totalPercent) {
      return { background: 'conic-gradient(#e2e8f0 0% 100%)' };
    }
    let acc = 0;
    const segments = this.analytics.ageBuckets.map((bucket, idx) => {
      const start = acc;
      acc += bucket.percent;
      return `${this.agePieColors[idx % this.agePieColors.length]} ${start}% ${acc}%`;
    });
    return { background: `conic-gradient(${segments.join(', ')})` };
  }

  getAgeColor(index: number) {
    return this.agePieColors[index % this.agePieColors.length];
  }

  getGenderPieStyle() {
    const totalPercent = this.analytics.genderMix.reduce((sum, g) => sum + g.percent, 0);
    if (!totalPercent) {
      return { background: 'conic-gradient(#e2e8f0 0% 100%)' };
    }
    let acc = 0;
    const segments = this.analytics.genderMix.map((g, idx) => {
      const start = acc;
      acc += g.percent;
      return `${this.genderPieColors[idx % this.genderPieColors.length]} ${start}% ${acc}%`;
    });
    return { background: `conic-gradient(${segments.join(', ')})` };
  }

  getGenderColor(index: number) {
    return this.genderPieColors[index % this.genderPieColors.length];
  }

  getGenderOffset(index: number): number {
    const cumulativePercent = this.analytics.genderMix
      .slice(0, index)
      .reduce((sum, item) => sum + item.percent, 0);
    return -(cumulativePercent * 4.4);
  }

  getTopDiagnoses(): Array<{ name: string; count: number }> {
    const diagnosisCounts = new Map<string, number>();
    this.patients.forEach(patient => {
      if (patient.diagnosis) {
        const diagnosis = patient.diagnosis.trim();
        diagnosisCounts.set(diagnosis, (diagnosisCounts.get(diagnosis) || 0) + 1);
      }
    });
    
    return Array.from(diagnosisCounts.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  }

  private readonly diagnosisColors = ['#7c3aed', '#3b82f6', '#06b6d4', '#10b981', '#f59e0b'];

  getDiagnosisColor(index: number): string {
    return this.diagnosisColors[index % this.diagnosisColors.length];
  }

  getDiagnosisSliceOffset(index: number): { x: number; y: number } {
    const topDiagnoses = this.getTopDiagnoses();
    if (!topDiagnoses.length || this.stats.total === 0) return { x: 0, y: 0 };

    const slicePercent = (topDiagnoses[index].count / this.stats.total) * 100;
    
    // Explode slices smaller than 15% of the total
    if (slicePercent >= 15) return { x: 0, y: 0 };

    // Calculate the middle angle of this slice
    let startAngle = 0;
    for (let i = 0; i < index; i++) {
      startAngle += (topDiagnoses[i].count / this.stats.total) * 360;
    }
    const sliceAngle = (topDiagnoses[index].count / this.stats.total) * 360;
    const midAngle = startAngle + sliceAngle / 2;

    // Offset distance: smaller slices get pushed out more
    const offsetDistance = 8; // pixels
    
    const midRad = (midAngle - 90) * Math.PI / 180;
    return {
      x: offsetDistance * Math.cos(midRad),
      y: offsetDistance * Math.sin(midRad)
    };
  }

  getDiagnosisPath(index: number, viewBoxSize: number = 120): string {
    const topDiagnoses = this.getTopDiagnoses();
    if (!topDiagnoses.length || this.stats.total === 0) return '';

    const center = viewBoxSize / 2;
    const radius = viewBoxSize / 2 - 10;
    const offset = this.getDiagnosisSliceOffset(index);

    let startAngle = 0;
    for (let i = 0; i < index; i++) {
      startAngle += (topDiagnoses[i].count / this.stats.total) * 360;
    }

    const sliceAngle = (topDiagnoses[index].count / this.stats.total) * 360;
    const endAngle = startAngle + sliceAngle;

    const startRad = (startAngle - 90) * Math.PI / 180;
    const endRad = (endAngle - 90) * Math.PI / 180;

    // Apply offset to all points
    const centerX = center + offset.x;
    const centerY = center + offset.y;
    const x1 = centerX + radius * Math.cos(startRad);
    const y1 = centerY + radius * Math.sin(startRad);
    const x2 = centerX + radius * Math.cos(endRad);
    const y2 = centerY + radius * Math.sin(endRad);

    const largeArc = sliceAngle > 180 ? 1 : 0;

    return `M ${centerX} ${centerY} L ${x1} ${y1} A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2} Z`;
  }

  buildSparklinePath(values: number[], width = 160, height = 40): string {
    if (!values.length) return '';
    const max = Math.max(...values, 1);
    const step = values.length > 1 ? width / (values.length - 1) : width;
    const points = values.map((v, i) => {
      const x = i * step;
      const y = height - (v / max) * height;
      return { x, y };
    });
    const path = points.reduce((acc, p, idx) => {
      return acc + `${idx === 0 ? 'M' : 'L'} ${p.x.toFixed(2)} ${p.y.toFixed(2)} `;
    }, '').trim();
    return path;
  }

  private buildMountainPaths(value: number, total: number, baseY: number): { line: string; area: string } {
    const pct = total > 0 ? Math.min(value / total, 1) : 0;
    // More responsive amplitude: minimum 10, up to ~58px at 100%
    const amp = 10 + Math.pow(pct, 0.85) * 48;
    const xs = [0, 40, 80, 120, 160, 200, 240, 280, 320];
    const ys = xs.map((_, idx) => {
      if (idx === 0) return baseY;
      return idx % 2 === 1 ? (baseY - amp) : (baseY + Math.max(amp * 0.35, 6));
    });

    const line = ys.reduce((acc, y, idx) => {
      const x = xs[idx];
      return acc + `${idx === 0 ? 'M' : 'L'} ${x} ${y} `;
    }, '').trim();

    const lastX = xs[xs.length - 1];
    const area = `${line} L ${lastX} 80 L 0 80 Z`;
    return { line, area };
  }

  getCriticalMountainPath(): string {
    return this.buildMountainPaths(this.stats.critical, this.stats.total || 1, 60).line;
  }

  getCriticalMountainAreaPath(): string {
    return this.buildMountainPaths(this.stats.critical, this.stats.total || 1, 60).area;
  }

  getStableMountainPath(): string {
    return this.buildMountainPaths(this.stats.stable, this.stats.total || 1, 50).line;
  }

  getStableMountainAreaPath(): string {
    return this.buildMountainPaths(this.stats.stable, this.stats.total || 1, 50).area;
  }

  getBloodGroups(): Array<{ type: string; count: number }> {
    const bloodTypes = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
    return bloodTypes.map(type => ({
      type,
      count: this.patients.filter(p => p.blood_group === type).length
    }));
  }

  getBloodGroupTotal(): number {
    return this.patients.filter(p => p.blood_group && p.blood_group !== '').length;
  }

  getBloodGroupColor(bloodType: string): string {
    // ABO-based palette: A=green, B=red, AB=amber, O=blue (light variants for negative)
    const colors: Record<string, string> = {
      'A+': '#16a34a',  // Green
      'A-': '#22c55e',  // Light Green
      'B+': '#ef4444',  // Red
      'B-': '#f87171',  // Light Red
      'AB+': '#f59e0b', // Amber
      'AB-': '#fbbf24', // Light Amber
      'O+': '#3b82f6',  // Blue
      'O-': '#60a5fa'   // Light Blue
    };
    return colors[bloodType] || '#64748b';
  }

  getStatusColor(status: string): string {
    const colors: any = {
      'admitted': '#3b82f6',
      'critical': '#ef4444',
      'observation': '#0ea5e9',
      'icu': '#f59e0b'
    };
    return colors[status?.toLowerCase()] || '#64748b';
  }

  openModal(patient: any = null) {
    this.editingPatient = patient;
    if (patient) {
      const admissionDate = patient.admission_date ? new Date(patient.admission_date) : new Date();
      this.form = { 
        ...patient,
        admission_day: admissionDate.getDate(),
        admission_month: (admissionDate.getMonth() + 1).toString(),
        admission_year: admissionDate.getFullYear()
      };
    } else {
      this.form = {
        name: '',
        age: '',
        gender: 'female',
        diagnosis: '',
        status: 'admitted',
        doctor: '',
        room: '',
        admission_day: new Date().getDate(),
        admission_month: (new Date().getMonth() + 1).toString(),
        admission_year: new Date().getFullYear()
      };
    }
    this.showModal = true;
  }

  closeModal() {
    this.showModal = false;
    this.editingPatient = null;
  }

  setView(view: 'patients' | 'analytics' | 'analytics2' | 'settings' | 'appointments' | 'admitted' | 'discharged' | 'critical') {
    this.activeView = view;
  }

  setStatusFilter(status: 'all' | 'admitted' | 'critical' | 'discharged' | 'stable') {
    // Jump to patients view while applying a status filter from the main menu
    this.filterStatus = status;
    this.activeView = 'patients';
  }

  toggleMenu() {
    this.showMenu = !this.showMenu;
  }

  getDateLabel(daysAgo: number): string {
    const date = new Date();
    date.setDate(date.getDate() + daysAgo);
    const day = date.getDate();
    const month = date.toLocaleDateString('en-US', { month: 'short' });
    return `${day} ${month}`;
  }

  handleMenuClick(action: string) {
    switch(action) {
      case 'patients':
        this.setView('patients');
        break;
      case 'appointments':
        this.setView('appointments');
        break;
      case 'admitted':
        this.setView('admitted');
        break;
      case 'discharged':
        this.setView('discharged');
        break;
      case 'critical':
        this.setView('critical');
        break;
      case 'analytics':
        this.setView('analytics');
        break;
      case 'analytics2':
        this.setView('analytics2');
        break;
      case 'settings':
        this.setView('settings');
        break;
    }
  }

  async savePatient() {
    this.isLoading = true;

    if (this.editingPatient) {
      const updated = { ...this.editingPatient, ...this.form };
      this.http.put(`${this.apiUrl}/${this.editingPatient._id}`, updated).subscribe({
        next: () => {
          this.showToast('Patient updated');
          this.closeModal();
          this.loadPatients();
          this.isLoading = false;
        },
        error: (err) => {
          console.error('Failed to update patient:', err);
          this.showToast('Failed to update patient', 'error');
          this.isLoading = false;
        }
      });
    } else {
      const admissionDate = new Date(
        parseInt(this.form.admission_year),
        parseInt(this.form.admission_month) - 1,
        parseInt(this.form.admission_day)
      );
      const { admission_day, admission_month, admission_year, ...patientData } = this.form;
      const newPatient = {
        patient_id: `P${Date.now()}`,
        ...patientData,
        admission_date: admissionDate.toISOString()
      };
      this.http.post(this.apiUrl, newPatient).subscribe({
        next: () => {
          this.showToast('Patient added');
          this.closeModal();
          this.loadPatients();
          this.isLoading = false;
        },
        error: (err) => {
          console.error('Failed to add patient:', err);
          this.showToast('Failed to add patient', 'error');
          this.isLoading = false;
        }
      });
    }
  }

  async deletePatient(patient: any) {
    if (confirm('Are you sure you want to delete this patient?')) {
      this.isLoading = true;
      this.http.delete(`${this.apiUrl}/${patient._id}`).subscribe({
        next: () => {
          this.showToast('Patient deleted successfully');
          this.loadPatients();
          this.isLoading = false;
        },
        error: (err) => {
          console.error('Failed to delete patient:', err);
          this.showToast('Failed to delete patient', 'error');
          this.isLoading = false;
        }
      });
    }
  }

  showToast(message: string, type: string = 'success') {
    const toastContainer = document.getElementById('toast-container');
    if (!toastContainer) return;
    
    const toast = document.createElement('div');
    toast.className = `toast px-6 py-4 rounded-lg shadow-lg text-white ${type === 'success' ? 'bg-green-500' : 'bg-red-500'}`;
    toast.textContent = message;
    toastContainer.appendChild(toast);
    
    setTimeout(() => {
      toast.style.animation = 'slideInRight 0.3s ease-out reverse';
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  saveSettings() {
    localStorage.setItem('dashboardConfig', JSON.stringify(this.config));
    if (document.body) {
      document.body.style.backgroundColor = this.config.background_color;
      document.body.style.color = this.config.text_color;
      document.body.style.fontFamily = `${this.config.font_family}, Inter, sans-serif`;
      document.body.style.fontSize = `${this.config.font_size}px`;
    }
    this.showToast('Settings saved successfully', 'success');
  }

  resetSettings() {
    if (confirm('Are you sure you want to reset all settings to default?')) {
      this.config = {
        background_color: "#f8fafc",
        surface_color: "#ffffff",
        text_color: "#1e293b",
        primary_action: "#3b82f6",
        secondary_action: "#64748b",
        font_family: "Inter",
        font_size: 14,
        dashboard_title: "Patient Management Dashboard",
        subtitle: "Healthcare Administration System"
      };
      localStorage.removeItem('dashboardConfig');
      this.saveSettings();
      this.showToast('Settings reset to default', 'success');
    }
  }

  private triggerDownload(blob: Blob, filename: string) {
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  }

  toggleExportMenu() {
    this.showExportMenu = !this.showExportMenu;
  }

  toggleAboutUs() {
    this.showAboutUs = !this.showAboutUs;
  }

  toggleDarkMode() {
    this.isDarkMode = !this.isDarkMode;
    if (this.isDarkMode) {
      this.config.background_color = '#1e293b';
      this.config.surface_color = '#334155';
      this.config.text_color = '#f1f5f9';
      this.config.secondary_action = '#94a3b8';
    } else {
      this.config.background_color = '#f8fafc';
      this.config.surface_color = '#ffffff';
      this.config.text_color = '#1e293b';
      this.config.secondary_action = '#64748b';
    }
    if (document.body) {
      document.body.style.backgroundColor = this.config.background_color;
      document.body.style.color = this.config.text_color;
    }
    localStorage.setItem('isDarkMode', this.isDarkMode.toString());
    localStorage.setItem('dashboardConfig', JSON.stringify(this.config));
    this.showToast(`${this.isDarkMode ? 'Dark' : 'Light'} mode activated`, 'success');
  }

  exportPatientsExcel(mode: 'basic' | 'full') {
    this.showExportMenu = false;
    this.isLoading = true;
    const modeLabel = mode === 'full' ? 'full-details' : 'patient-info';

    this.http.get(`${this.apiUrl}/export?mode=${mode}`, { responseType: 'blob' }).subscribe({
      next: (blob) => {
        const filename = `patients-${modeLabel}-${new Date().toISOString().split('T')[0]}.xlsx`;
        this.triggerDownload(blob, filename);
        this.showToast(
          `Exported ${mode === 'full' ? 'full patient details' : 'patient info'} to Excel`,
          'success'
        );
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Failed to export patients:', err);
        this.showToast('Failed to export patients', 'error');
        this.isLoading = false;
      }
    });
  }

  // Appointment Methods
  openAppointmentModal(appointment: any = null) {
    this.editingAppointment = appointment;
    if (appointment) {
      this.appointmentForm = { ...appointment };
    } else {
      this.appointmentForm = {
        patient_name: '',
        date: new Date().toISOString().split('T')[0],
        time: '',
        doctor: '',
        department: '',
        notes: '',
        status: 'scheduled'
      };
    }
    this.showAppointmentModal = true;
  }

  closeAppointmentModal() {
    this.showAppointmentModal = false;
    this.editingAppointment = null;
    this.appointmentSaveSuccess = false;
  }

  saveAppointment() {
    this.isLoading = true;
    this.appointmentSaveSuccess = false;

    if (this.editingAppointment) {
      const updated = { ...this.editingAppointment, ...this.appointmentForm };
      this.http.put(`${this.appointmentsApiUrl}/${this.editingAppointment._id}`, updated).subscribe({
        next: () => {
          this.appointmentSaveSuccess = true;
          this.showToast('✓ Appointment updated successfully', 'success');
          setTimeout(() => {
            this.closeAppointmentModal();
            this.loadAppointments();
            this.isLoading = false;
            this.appointmentSaveSuccess = false;
          }, 1500);
        },
        error: (err) => {
          console.error('Failed to update appointment:', err);
          this.showToast('Failed to update appointment', 'error');
          this.isLoading = false;
          this.appointmentSaveSuccess = false;
        }
      });
    } else {
      this.http.post(this.appointmentsApiUrl, this.appointmentForm).subscribe({
        next: () => {
          this.appointmentSaveSuccess = true;
          this.showToast('✓ Appointment booked successfully!', 'success');
          setTimeout(() => {
            this.closeAppointmentModal();
            this.loadAppointments();
            this.isLoading = false;
            this.appointmentSaveSuccess = false;
          }, 1500);
        },
        error: (err) => {
          console.error('Failed to schedule appointment:', err);
          this.showToast('Failed to schedule appointment', 'error');
          this.isLoading = false;
          this.appointmentSaveSuccess = false;
        }
      });
    }
  }

  editAppointment(appointment: any) {
    this.openAppointmentModal(appointment);
  }

  deleteAppointment(id: string) {
    if (confirm('Are you sure you want to cancel this appointment?')) {
      this.isLoading = true;
      this.http.delete(`${this.appointmentsApiUrl}/${id}`).subscribe({
        next: () => {
          this.showToast('Appointment cancelled', 'success');
          this.loadAppointments();
          this.isLoading = false;
        },
        error: (err) => {
          console.error('Failed to cancel appointment:', err);
          this.showToast('Failed to cancel appointment', 'error');
          this.isLoading = false;
        }
      });
    }
  }

  getAppointmentStatusColor(status: string): string {
    const colors: any = {
      'scheduled': '#3b82f6',
      'completed': '#10b981',
      'cancelled': '#ef4444',
      'rescheduled': '#f59e0b'
    };
    return colors[status?.toLowerCase()] || '#64748b';
  }

  getAppointmentCountByStatus(status: string): number {
    return this.appointments.filter(a => a.status?.toLowerCase() === status.toLowerCase()).length;
  }

  getMaxAppointmentCount(): number {
    const counts = [
      this.getAppointmentCountByStatus('scheduled'),
      this.getAppointmentCountByStatus('completed'),
      this.getAppointmentCountByStatus('cancelled'),
      this.getAppointmentCountByStatus('rescheduled')
    ];
    const max = Math.max(...counts);
    return max === 0 ? 1 : max; // Return at least 1 to avoid division by zero
  }

  getUniqueDepartments(): Array<{ name: string; count: number; percentage: number }> {
    if (this.appointments.length === 0) return [];
    
    const deptCounts: { [key: string]: number } = {};
    this.appointments.forEach(appointment => {
      const dept = appointment.department || 'Unspecified';
      deptCounts[dept] = (deptCounts[dept] || 0) + 1;
    });

    const total = this.appointments.length;
    return Object.entries(deptCounts)
      .map(([name, count]) => ({
        name,
        count,
        percentage: Math.round((count / total) * 100)
      }))
      .sort((a, b) => b.count - a.count);
  }
}