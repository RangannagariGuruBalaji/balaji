declare global {
  interface DataSdkInitResult {
    isOk: boolean;
  }

  interface DataSdk {
    init: (handler: { onDataChanged: (data: any) => void }) => Promise<DataSdkInitResult>;
    create: (patient: any) => Promise<{ isOk: boolean; data?: any }>;
    update: (patient: any) => Promise<{ isOk: boolean; data?: any }>;
    delete: (patient: any) => Promise<{ isOk: boolean }>;
  }

  interface Window {
    dataSdk?: DataSdk;
  }
}

export {};
