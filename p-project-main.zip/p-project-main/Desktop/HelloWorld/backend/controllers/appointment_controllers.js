const mongoose = require('mongoose');
const Appointment = require('../models/appointment_model');

// In-memory fallback when MongoDB not connected
const memoryStore = [];
const isDbReady = () => mongoose.connection && mongoose.connection.readyState === 1;

exports.listAppointments = async (req, res) => {
  try {
    if (isDbReady()) {
      const appointments = await Appointment.find({}, { __v: 0 }).lean();
      return res.json(appointments);
    }
    return res.json(memoryStore);
  } catch (err) {
    res.status(500).json({ message: 'Failed to list appointments', error: err.message });
  }
};

exports.createAppointment = async (req, res) => {
  try {
    const payload = req.body;

    if (isDbReady()) {
      const created = await Appointment.create(payload);
      return res.status(201).json(created);
    }
    const newAppointment = { ...payload, _id: Date.now().toString() };
    memoryStore.push(newAppointment);
    return res.status(201).json(newAppointment);
  } catch (err) {
    res.status(500).json({ message: 'Failed to create appointment', error: err.message });
  }
};

exports.updateAppointment = async (req, res) => {
  try {
    const id = req.params.id;
    const updates = req.body;

    if (isDbReady()) {
      const updated = await Appointment.findByIdAndUpdate(id, updates, { new: true }).lean();
      if (!updated) return res.status(404).json({ message: 'Appointment not found' });
      return res.json(updated);
    }
    const idx = memoryStore.findIndex(a => a._id === id);
    if (idx === -1) return res.status(404).json({ message: 'Appointment not found' });
    memoryStore[idx] = { ...memoryStore[idx], ...updates };
    return res.json(memoryStore[idx]);
  } catch (err) {
    res.status(500).json({ message: 'Failed to update appointment', error: err.message });
  }
};

exports.deleteAppointment = async (req, res) => {
  try {
    const id = req.params.id;

    if (isDbReady()) {
      const deleted = await Appointment.findByIdAndDelete(id);
      if (!deleted) return res.status(404).json({ message: 'Appointment not found' });
      return res.json({ message: 'Appointment deleted', deleted });
    }
    const idx = memoryStore.findIndex(a => a._id === id);
    if (idx === -1) return res.status(404).json({ message: 'Appointment not found' });
    const deleted = memoryStore.splice(idx, 1);
    return res.json({ message: 'Appointment deleted', deleted: deleted[0] });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete appointment', error: err.message });
  }
};
