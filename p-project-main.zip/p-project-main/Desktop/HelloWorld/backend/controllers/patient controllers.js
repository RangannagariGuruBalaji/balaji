const mongoose = require('mongoose');
const Patient = require('../models/patient_model');

// In-memory fallback when MongoDB not connected
const memoryStore = [];
const isDbReady = () => mongoose.connection && mongoose.connection.readyState === 1;

exports.listPatients = async (req, res) => {
  try {
    if (isDbReady()) {
      const patients = await Patient.find({}, { __v: 0 }).lean();
      return res.json(patients);
    }
    return res.json(memoryStore);
  } catch (err) {
    res.status(500).json({ message: 'Failed to list patients', error: err.message });
  }
};

exports.createPatient = async (req, res) => {
  try {
    const payload = req.body;
    if (!payload.patient_id) {
      payload.patient_id = `P${Date.now()}`;
    }
    if (!payload.admission_date) {
      payload.admission_date = new Date().toISOString();
    }

    if (isDbReady()) {
      const created = await Patient.create(payload);
      return res.status(201).json(created);
    }
    memoryStore.push(payload);
    return res.status(201).json(payload);
  } catch (err) {
    res.status(500).json({ message: 'Failed to create patient', error: err.message });
  }
};

exports.updatePatient = async (req, res) => {
  try {
    const id = req.params.id;
    const updates = req.body;

    if (isDbReady()) {
      // Try to find by MongoDB _id first, then by patient_id
      let updated = await Patient.findByIdAndUpdate(id, updates, { new: true }).lean();
      if (!updated) {
        updated = await Patient.findOneAndUpdate({ patient_id: id }, updates, { new: true }).lean();
      }
      if (!updated) return res.status(404).json({ message: 'Patient not found' });
      return res.json(updated);
    }
    const idx = memoryStore.findIndex(p => p.patient_id === id);
    if (idx === -1) return res.status(404).json({ message: 'Patient not found' });
    memoryStore[idx] = { ...memoryStore[idx], ...updates };
    return res.json(memoryStore[idx]);
  } catch (err) {
    res.status(500).json({ message: 'Failed to update patient', error: err.message });
  }
};

exports.deletePatient = async (req, res) => {
  try {
    const id = req.params.id;
    if (isDbReady()) {
      // Try to find by MongoDB _id first, then by patient_id
      let deleted = await Patient.findByIdAndDelete(id).lean();
      if (!deleted) {
        deleted = await Patient.findOneAndDelete({ patient_id: id }).lean();
      }
      if (!deleted) return res.status(404).json({ message: 'Patient not found' });
      return res.json({ message: 'Deleted', patient_id: deleted.patient_id || id });
    }
    const idx = memoryStore.findIndex(p => p.patient_id === id);
    if (idx === -1) return res.status(404).json({ message: 'Patient not found' });
    memoryStore.splice(idx, 1);
    return res.json({ message: 'Deleted', patient_id: id });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete patient', error: err.message });
  }
};
