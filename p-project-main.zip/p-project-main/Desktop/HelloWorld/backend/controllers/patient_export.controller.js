const xlsx = require("xlsx");
const Patient = require("../models/patient_model");

exports.exportPatientsToExcel = async (req, res) => {
  try {
    const mode = req.query.mode === "full" ? "full" : "basic";

    // Pick columns based on the requested mode
    const projection = mode === "full"
      ? { __v: 0 }
      : {
          _id: 0,
          patient_id: 1,
          name: 1,
          age: 1,
          gender: 1,
          status: 1,
          doctor: 1,
          admission_date: 1
        };

    const patients = await Patient.find({}, projection).lean();

    const worksheet = xlsx.utils.json_to_sheet(patients);
    const workbook = xlsx.utils.book_new();
    xlsx.utils.book_append_sheet(workbook, worksheet, "Patients");

    // Stream the Excel file to the client
    const buffer = xlsx.write(workbook, { bookType: "xlsx", type: "buffer" });
    const filename = `patients-${mode === "full" ? "full-details" : "info-only"}-${new Date()
      .toISOString()
      .split("T")[0]}.xlsx`;

    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    );

    res.send(buffer);
  } catch (error) {
    console.error("Export failed", error);
    res.status(500).json({ message: "Export failed", error: error.message });
  }
};
