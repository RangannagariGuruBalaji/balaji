const mongoose = require('mongoose');

const PatientSchema = new mongoose.Schema({
  patient_id: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  age: { type: Number, required: true },
  gender: { type: String, enum: ['female','male','other','children'], lowercase: true, required: true },
  blood_group: { type: String, enum: ['A+','A-','B+','B-','AB+','AB-','O+','O-'], default: '' },
  diagnosis: { type: String, default: '' },
  status: { type: String, enum: ['admitted','critical','observation','icu','stable','discharged'], lowercase: true, required: true },
  doctor: { type: String, default: '' },
  room: { type: String, default: '' },
  admission_date: { type: String, required: true }
}, { timestamps: true });

module.exports = mongoose.models.Patient || mongoose.model('Patient', PatientSchema);
