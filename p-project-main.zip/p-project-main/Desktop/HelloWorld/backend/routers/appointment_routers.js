const express = require("express");
const router = express.Router();

const { listAppointments, createAppointment, updateAppointment, deleteAppointment } = require("../controllers/appointment_controllers");

// CRUD Appointments
router.get("/", listAppointments);
router.post("/", createAppointment);
router.put("/:id", updateAppointment);
router.delete("/:id", deleteAppointment);

module.exports = router;
