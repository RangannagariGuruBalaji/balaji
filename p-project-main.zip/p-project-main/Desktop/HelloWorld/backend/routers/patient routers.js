const express = require("express");
const router = express.Router();

const { exportPatientsToExcel } = require("../controllers/patient_export.controller");
const { listPatients, createPatient, updatePatient, deletePatient } = require("../controllers/patient controllers");

// EXPORT PATIENT DATASET
router.get("/export", exportPatientsToExcel);

// CRUD Patients
router.get("/", listPatients);
router.post("/", createPatient);
router.put("/:id", updatePatient);
router.delete("/:id", deletePatient);

module.exports = router;
