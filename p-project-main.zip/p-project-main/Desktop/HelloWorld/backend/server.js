const express = require('express');
const dotenv = require('dotenv');
const path = require('path');
const cors = require('cors');
const connectDB = require(path.join(__dirname, 'config', 'db'));

dotenv.config({ path: path.join(__dirname, '.env') });
connectDB();

const app = express();

// Mobile-friendly CORS configuration
const corsOptions = {
  origin: function (origin, callback) {
    const allowedOrigins = [
      'http://localhost:3000',
      'http://localhost:4200',
      'http://localhost:5000',
      process.env.FRONTEND_URL
    ];
    const isLocalhost = !!origin && /^http:\/\/localhost:\d+$/.test(origin);
    if (!origin || isLocalhost || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  credentials: true,
  maxAge: 86400
};

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));
app.use(cors(corsOptions));

// Set security headers for mobile browsers
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Credentials', 'true');
  res.header('X-Content-Type-Options', 'nosniff');
  res.header('X-Frame-Options', 'SAMEORIGIN');
  res.header('X-XSS-Protection', '1; mode=block');
  next();
});

app.get('/', (req, res) => {
  res.send('API running with MongoDB');
});

// Patients API
const patientRouter = require(path.join(__dirname, 'routers', 'patient routers'));
app.use('/api/patients', patientRouter);

// Appointments API
const appointmentRouter = require(path.join(__dirname, 'routers', 'appointment_routers'));
app.use('/api/appointments', appointmentRouter);


const PORT = process.env.PORT || 5000;
app.listen(PORT, () =>
  console.log(`Server running on port ${PORT}`)
);
